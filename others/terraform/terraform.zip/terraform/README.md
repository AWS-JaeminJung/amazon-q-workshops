# To-Do 애플리케이션 ECS 배포 가이드

이 테라폼 코드는 To-Do 애플리케이션(FastAPI 백엔드 + React 프론트엔드)을 AWS ECS에 배포하기 위한 인프라를 구성합니다.

## 구성 요소

- VPC, 서브넷, 보안 그룹 등의 네트워크 인프라
- ECR 저장소 (프론트엔드 및 백엔드 이미지용)
- ECS 클러스터, 서비스, 태스크 정의
- Application Load Balancer
- CloudWatch 로그 그룹
- IAM 역할 및 정책

## 사전 요구사항

- AWS CLI가 설치되어 있고 적절한 권한으로 구성되어 있어야 합니다.
- Terraform이 설치되어 있어야 합니다.
- Docker가 설치되어 있어야 합니다.

## 배포 단계

### 1. 테라폼 초기화 및 배포

```bash
cd terraform
terraform init
terraform plan
terraform apply
```

### 2. ECR 저장소에 이미지 푸시

테라폼 배포가 완료되면 ECR 저장소 URL이 출력됩니다. 이 URL을 사용하여 Docker 이미지를 빌드하고 푸시합니다.

#### 백엔드 이미지 빌드 및 푸시

```bash
# AWS 로그인
aws ecr get-login-password --region ap-northeast-2 | docker login --username AWS --password-stdin $(terraform output -raw backend_repository_url | cut -d'/' -f1)

# 백엔드 이미지 빌드
cd ../backend
docker build -t todo-app-backend .

# 이미지 태그 지정 및 푸시
docker tag todo-app-backend:latest $(terraform output -raw backend_repository_url):latest
docker push $(terraform output -raw backend_repository_url):latest
```

#### 프론트엔드 이미지 빌드 및 푸시

```bash
# 프론트엔드 이미지 빌드
cd ../frontend
docker build -t todo-app-frontend .

# 이미지 태그 지정 및 푸시
docker tag todo-app-frontend:latest $(terraform output -raw frontend_repository_url):latest
docker push $(terraform output -raw frontend_repository_url):latest
```

### 3. 애플리케이션 접속

이미지 푸시가 완료되면 ECS 서비스가 자동으로 새 이미지를 배포합니다. 애플리케이션은 다음 URL에서 접속할 수 있습니다:

```
http://<ALB_DNS_NAME>
```

ALB DNS 이름은 테라폼 출력에서 확인할 수 있습니다:

```bash
terraform output alb_dns_name
```

## 리소스 정리

작업이 완료되면 다음 명령으로 모든 리소스를 삭제할 수 있습니다:

```bash
terraform destroy
```

## 주의사항

- 이 코드는 기본적으로 ap-northeast-2 리전(서울)을 사용합니다. 다른 리전을 사용하려면 variables.tf 파일에서 region 변수를 수정하세요.
- 프로덕션 환경에서는 HTTPS를 구성하고 보안 설정을 강화하는 것이 좋습니다.
- 데이터베이스 연결이 필요한 경우 추가 구성이 필요합니다.
